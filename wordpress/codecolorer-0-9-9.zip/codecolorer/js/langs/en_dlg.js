tinyMCE.addI18n('en.codecolorer_dlg',{
  general_tab_desc: 'CodeColorer block',
  advanced_tab_desc: 'Advanced options',
  language: 'Language',
  inline: 'This is inline code block',
  line_numbers: 'Show line numbers',
  code: 'Code snippet',
  theme: 'Theme',
  current_theme: 'Current theme',
  tab_size: 'Tab size',
  disable_keyword_linking: 'Disable keyword linking',
  or: 'or'
});